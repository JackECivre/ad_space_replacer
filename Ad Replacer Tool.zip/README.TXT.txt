Ad Replacer Tool V1.2
--------------------------------------------------
Overview

The Ad Replacer Tool V1.2 is designed to help agencies create mock-up visuals by displaying advertisement visuals on websites for demonstration purposes.

⚠️ Important Notes:

This tool is strictly for creating mock-up visuals and does NOT publish ads in live ad spaces.
Please use this tool responsibly and refrain from any fraudulent activities.
The creator of this tool assumes no responsibility for its misuse.
--------------------------------------------------

Installation and Usage Instructions

Step 1: Extract Files
Download the provided .zip file containing the Ad Replacer Tool and ChromeDriver.

Step 2: Run the Tool
Open the .zip file and run the Ad Replacer Tool.exe directly.
Upon running, the command prompt will briefly appear.

Step 3: Set Up ChromeDriver
User will be asked to select the ChromeDriver file. If the ChromeDriver provided is not suitable please download the suitable version. ChromeDriver link and your computer's information will be provided at the command prompt.

Step 4: Re-Run the Tool
Open a Chrome browser and enter the following address in the address bar:

127.0.0.1:5001

You can now use the tool to create mock-up advertisement visuals.

--------------------------------------------------
Disclaimer:

The Ad Replacer Tool is provided as-is without any guarantees. Use it at your own discretion and ensure compliance with applicable laws and ethical guidelines.

